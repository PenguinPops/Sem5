#!/bin/bash
g++ main.cpp Person.cpp Teacher.cpp Student.cpp -o main && ./main