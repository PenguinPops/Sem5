#!/bin/bash
g++ main.cpp Animal.cpp Dog.cpp Cat.cpp -o main && ./main